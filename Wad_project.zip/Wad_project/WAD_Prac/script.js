function takeValue()
{
    var fname=document.getElementById("fname").value;
    document.write(fname+"<br");

    var mname=document.getElementById("mname").value;
    document.write(mname+"<br>");

    var lname=document.getElementById("lname").value;
    document.write(lname+"<br");


}